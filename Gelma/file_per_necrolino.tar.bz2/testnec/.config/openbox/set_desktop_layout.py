#!/usr/bin/env python3
"""
Imposta la proprietà EWMH _NET_DESKTOP_LAYOUT su root window X11.
Specifica:
- orientation: 0 (_NET_WM_ORIENTATION_HORZ)
- columns: 4
- rows: 3
- starting_corner: 0 (_NET_WM_TOPLEFT)
"""
import ctypes
import os
import sys

def set_desktop_layout(cols=4, rows=3, orientation=0, start_corner=0):
    display_name = os.environ.get("DISPLAY")
    if not display_name:
        return

    try:
        x11 = ctypes.cdll.LoadLibrary("libX11.so.6")
    except Exception as e:
        sys.stderr.write(f"Impossibile caricare libX11: {e}\n")
        return

    x11.XOpenDisplay.restype = ctypes.c_void_p
    x11.XDefaultRootWindow.restype = ctypes.c_ulong
    x11.XInternAtom.restype = ctypes.c_ulong

    display = x11.XOpenDisplay(display_name.encode("utf-8"))
    if not display:
        return

    root = x11.XDefaultRootWindow(display)
    prop_atom = x11.XInternAtom(display, b"_NET_DESKTOP_LAYOUT", False)
    cardinal_atom = x11.XInternAtom(display, b"CARDINAL", False)

    # 4 valori: orientation (0=HORZ), cols (4), rows (3), starting_corner (0=TOPLEFT)
    data = (ctypes.c_ulong * 4)(orientation, cols, rows, start_corner)

    PropModeReplace = 0
    x11.XChangeProperty(
        display,
        root,
        prop_atom,
        cardinal_atom,
        32,
        PropModeReplace,
        ctypes.cast(data, ctypes.c_char_p),
        4
    )
    x11.XFlush(display)
    x11.XCloseDisplay(display)

if __name__ == "__main__":
    cols = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    rows = int(sys.argv[2]) if len(sys.argv) > 2 else 3
    set_desktop_layout(cols, rows)
